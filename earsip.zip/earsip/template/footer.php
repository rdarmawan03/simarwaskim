</div>
<!-- Akhir Container -->

		<div class="fixed-bottom">
			<footer class="bg-primary text-center text-white pt-2 pb-2 mt-3">Copyright 2020 - <?=date ('Y')?>&nbsp&nbspI&nbsp&nbspDISPERKIMTA Kabupaten Cilacap</footer>
		</div>
    

    <!-- Optional JavaScript; choose one of the two! -->
    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>

  </body>
</html>