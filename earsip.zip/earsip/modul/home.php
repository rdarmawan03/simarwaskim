<div class="jumbotron mt-3">
  <h1 class="display-4">Selamat datang, admin :)</h1>
  <p class="lead">E-Arsip adalah aplikasi yang memudahkan anda dalam pengelolaan surat keluar.</p>
  <hr class="my-4">
  <p>Silakan pilih menu di atas sesuai dengan kebutuhan anda.</p>
  <a class="btn btn-danger btn-lg" href="logout.php" role="button">Logout</a>
</div>