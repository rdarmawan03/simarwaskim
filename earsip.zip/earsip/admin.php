<?php include "config/koneksi.php"; ?>

<?php include "template/header.php"; ?>

<?php include "content.php"; ?>

<?php include "template/footer.php"; ?>


			